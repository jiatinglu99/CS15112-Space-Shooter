# 15-122 Foundamentals of Programming and Computer Science
# Full Name: Terry Lu
# Andrew ID: jiatingl
# Section: A
# Date: 07/30/2017
# Homework: Term Project
# This game is similar to Raiden III, and iOS game -- Gemini
####################################
# Citation
####################################
'''
1. I used the animation barebone program from the course 
   website
'''
####################################
# Imports
####################################
import math
import random
from tkinter import *
from Background import *
from UserInterface import *
from UserAircraft import *
from UserLaserCollection import *
from SpecialEffects import *
from EnemyShipCollection import *
from EnemyLaserCollection import *
####################################
# customize these functions
####################################
def init(data):
    data.background = Background(data)
    data.userInterface = UserInterface(data)
    data.userAircraft = UserAircraft(data)
    data.userLaserCollection = UserLaserCollection(30, data)
    data.specialEffectCollection = SpecialEffectCollection(200, data)
    data.enemyShipCollection = EnemyShipCollection(15, data)
    data.enemyLaserCollection = EnemyLaserCollection(30, data)

def mousePressed(event, data):
    data.userInterface.mousePressed(event, data)

def keyPressed(event, data):
    data.userInterface.keyPressed(event, data)

def timerFired(data):
    data.userInterface.run(data)

def cursorEntered(event, data):
    data.userAircraft.updateTargetPostion(event.x, event.y)

def redrawAll(canvas, data):
    data.userInterface.draw(canvas, data)


####################################
# use the run function as-is
####################################

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)

    def cursorEnterWrapper(event, canvas, data):
        cursorEntered(event,data)
        
    class Struct(object): pass
    data = Struct()
    data.width = width
    data.height = height
    data.timerDelay = 5
    root = Tk()
    init(data)
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    root.bind("<Motion>", lambda event:
                            cursorEnterWrapper(event, canvas, data))
    root.config(cursor="none")
    timerFiredWrapper(canvas, data)
    root.mainloop()  
    print("bye!")

run(600, 900)