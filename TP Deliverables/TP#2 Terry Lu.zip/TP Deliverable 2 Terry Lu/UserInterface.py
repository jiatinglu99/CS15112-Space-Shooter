# 15-122 Foundamentals of Programming and Computer Science
# Full Name: Terry Lu
# Andrew ID: jiatingl
# Section: A
# Date: 08/07/2017
# Homework: Term Project
# Title: User Interface File

import math
import random

class UserInterface(object):
    def __init__(self, data):
        self.w = data.width
        self.h = data.height
        self.isOnStartMenu = True
        self.isFighting = False

    def command(self):
        if self.isOnStartMenu:
            return 'Start'
        elif self.isFighting:
            return 'Fight'

    def mousePressed(self, event, data):
        self.isOnStartMenu = not self.isOnStartMenu
        self.isFighting = not self.isFighting

    def keyPressed(self, event, data):
        self.isOnStartMenu = False
        self.isFighting = True
        
    def run(self, data):
        if (self.command() == 'Start'):
            data.background.run()
        elif (self.command() == 'Fight'):
            data.background.run()
            data.userAircraft.run(data)
            data.userLaserCollection.run()
            data.specialEffectCollection.run()
            data.enemyShipCollection.spawnShips(data, 2)
            data.enemyShipCollection.run(data)
            data.enemyLaserCollection.run(data)

    def draw(self, canvas, data):
        if self.command() == 'Start':
            data.background.draw(canvas)
            self.drawStartMenu(canvas, data)
        elif self.command() == 'Fight':
            data.background.draw(canvas)
            data.enemyShipCollection.draw(canvas)
            data.enemyLaserCollection.draw(canvas)
            data.userAircraft.draw(canvas)
            data.userLaserCollection.draw(canvas)
            data.specialEffectCollection.draw(canvas)
            self.drawHP(canvas, data)

    def drawHP(self, canvas, data):
        x = 20
        y = 40
        canvas.create_text(x, y, 
                           text = 'HP '+str(data.userAircraft.getHP()),
                           font = 'Arial 25', anchor = 'sw', fill = 'snow')

    def drawStartMenu(self, canvas, data):
        title = 'Alien Strike'
        x = self.w/2
        y = self.h/3
        canvas.create_text(x, y, text = title, 
                           font = 'Arial 50', fill = 'snow')
        text = 'Press Any Key To Play'
        x = self.w/2
        y = self.h/2
        canvas.create_text(x, y, text = text, 
                           font = 'Arial 30', fill = 'snow')
        
        