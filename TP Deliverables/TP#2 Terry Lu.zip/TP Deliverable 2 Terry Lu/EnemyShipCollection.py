# 15-122 Foundamentals of Programming and Computer Science
# Full Name: Terry Lu
# Andrew ID: jiatingl
# Section: A
# Date: 08/06/2017
# Homework: Term Prject
# Title: Enemy Ships Collection File
from tkinter import *
import math
import random

def degreeToRadian(degree):
    degree %= 360
    return degree/math.pi

def degreeToDir(degree):
    rad = degreeToRadian(degree)
    x = math.cos(rad)
    y = math.sin(rad)
    return (x, y)
    

class EnemyShipCollection(object):
    def __init__(self, maxE, data):
        self.collection = list()
        self.w = data.width
        self.h = data.height
        self.maxEnemyNum = maxE
        self.interval = 1000
        self.counter = 0 # list index counter
        self.timeCounter = 0# spawn interval counter
        self.modelList = list()
        for i in range(1, 6):
            file = 'Enemy' + str(i) + '.png'
            self.modelList.append(PhotoImage(file = file))
        for i in range(self.maxEnemyNum):
            self.collection.append(EnemyShip())

    def spawnShips(self, data, num):
        if self.timeToSpawn(data, self.interval):
            margin = 100
            for i in range(num):
                self.spawn(random.randint(margin, self.w - margin))

    def spawn(self, x):
        self.collection[self.counter] = EnemyShip(True, x, (0, 1), 1, 270, self.modelList)
        self.counter += 1
        if self.counter >= self.maxEnemyNum:
            self.counter = 0

    def run(self, data):
        for enemyShip in self.collection:
            enemyShip.run(data)
            enemyShip.borderDetect(self.w, self.h)
            enemyShip.hitDetect(data.userLaserCollection, data.specialEffectCollection)

    def draw(self, canvas):
        for enemyShip in self.collection:
            enemyShip.draw(canvas)
    
    def timeToSpawn(self, data, time):
        self.timeCounter += 1
        if self.timeCounter > time//data.timerDelay:
            self.timeCounter = 0
            return True
        return False

def distance(a, b, x, y):
    return ((a-x)**2+(b-y)**2)**0.5

class EnemyShip(object):
    def __init__(self, present = False, x = 0, direction = (0,0), speed = 0, degree = 0, modelList = []):
        self.x = x
        self.y = -20
        self.isPresent = present
        self.photo = random.choice(modelList).subsample(6, 6) if present else 0
        self.direction = direction
        self.speed = speed
        self.timeCounter = 0
        self.degree = 270

    def run(self, data):
        if self.isPresent:
            self.move()
            #self.generateTrail(data.specialEffectCollection)
            if self.timeToShoot(data, 500):
                self.shoot(data)
    
    def getPresent(self):
        return self.isPresent

    def hitDetect(self, laserCollection, effectCollection):
        for userLaser in laserCollection.getCollection():
            if userLaser.getPresent() and self.getPresent():
                if self.inHitRange(userLaser.getPosition()):
                    userLaser.destory(effectCollection)
                    self.destory(effectCollection)

    def inHitRange(self, laserPosition):
        margin = 20
        lx, ly = laserPosition
        if (lx - margin < self.x < lx + margin and 
            ly - margin < self.y < ly + margin and
            distance(lx, ly, self.x, self.y) < margin):
                return True
        return False
            
    def destory(self, effectCollection):
        self.generateExplosion(effectCollection)
        self.isPresent = False # can set a timer of dying

    def generateExplosion(self, effectCollection):
        effectCollection.addExplosion(self.x, self.y, (0, 0), random.randint(20,25))
        # Add more complication here
        for i in range(random.randint(3,5)):
            dirt = self.randomDirection()
            size = random.randint(15, 25)
            depth = size**0.5//1
            self.explosionTrail(effectCollection, self.x, self.y, dirt, size, depth)
    
    def explosionTrail(self, effectCollection, x, y, dirt, size, depth):
        if depth == 0:
            return None
        else:
            speed = random.uniform(10, 40)
            x += speed * dirt[0]
            y += speed * dirt[1]
            size -= random.randint(2, 6)
            effectCollection.addExplosion(x, y, dirt, size)
            self.explosionTrail(effectCollection, x, y, dirt, size, depth-1)
            
    def randomDirection(self):# generate a random direction
        x = random.uniform(-1, 1)
        y = (1 - x**2)**0.5
        y = -y if random.choice([True, False]) else y # Allow all direction
        return (x, y)

    def move(self):
        if self.isPresent:
            self.x = self.speed * self.direction[0]+self.x
            self.y = self.speed * self.direction[1]+self.y

    # def generateTrail(self, eCollection): # SpecialEffectCollection
    #     w = 12
    #     h = 32
    #     speed = 6
    #     gap = 0.05
    #     eCollection.addEffect(self.x - w, self.y + h, (random.uniform(-gap,gap),1+random.uniform(-0.5, 1)), speed)
    #     eCollection.addEffect(self.x + w, self.y + h, (random.uniform(-gap,gap),1+random.uniform(-0.5, 1)), speed)

    def shoot(self, data):
        if self.isPresent:
            w = 0
            h = 0
            speed = 3
            data.enemyLaserCollection.addLaser(self.x-w, self.y - h, (0,1), speed)

    def draw(self, canvas):
        if self.isPresent:
            #tempPhoto = self.photo.rotate(self.degree)
            canvas.create_image(self.x, self.y, image = self.photo)

    # TODO: enemy shoot
    def timeToShoot(self, data, time):
        self.timeCounter += 1
        if self.timeCounter >= time//data.timerDelay:
            self.timeCounter = 0
            return True
        return False

    def borderDetect(self, w, h):
        if self.isPresent:
            margin = 20
            if self.y > h: 
                self.isPresent = False