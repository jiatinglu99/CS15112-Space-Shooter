# 15-122 Foundamentals of Programming and Computer Science
# Full Name: Terry Lu
# Andrew ID: jiatingl
# Section: A
# Date: 07/30/2017
# Homework: Term Prject
# Title: User Aircraft File
from tkinter import *
import math
class UserAircraft(object):
    def __init__(self, data):
        self.x = data.width/2
        self.y = data.height/5*4
        self.speed = data.width/300
        self.photo = PhotoImage(file = "User Aircraft.png").subsample(6, 6)
        self.targetX = self.x
        self.targetY = self.y
        self.timeCounter = 0
        self.switch = False

    def updateTargetPostion(self, x, y):
        self.targetX = x
        self.targetY = y

    def run(self, data):
        self.move()
        if self.timeToShoot(data, 50):
            self.shoot(data)
    
    def move(self):
        (self.x, self.y) = self.derp(self.x, self.y, self.targetX, self.targetY)

    def shoot(self, data):
        w = 12
        h = 8
        speed = 8
        if self.switch:
            data.userLaserCollection.addLaser(self.x-w, self.y - h, (0,-1), speed)
        else: data.userLaserCollection.addLaser(self.x+w, self.y - h, (0,-1), speed)
        self.switch = not self.switch
    def draw(self, canvas):
        canvas.create_image(self.x, self.y, image = self.photo)

    def timeToShoot(self, data, time):
        self.timeCounter += 1
        if self.timeCounter >= time//data.timerDelay:
            self.timeCounter = 0
            return True
        return False

    def derp(self, a, b, x, y):
        # smoothen the movement of the aircraft
        # x and y increase toward targeted x and y at an exponential rate
        rate = 0.15
        resultX = a + (x-a)*rate
        resultY = b + (y-b)*rate
        return (resultX, resultY)