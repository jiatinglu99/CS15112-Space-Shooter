# 15-122 Foundamentals of Programming and Computer Science
# Full Name: Terry Lu
# Andrew ID: jiatingl
# Section: A
# Date: 07/30/2017
# Homework: Term Prject
# Title: User Laser collection as well as all types of weapons
import math
import random
class specialEffectCollection():
    def __init__(self, maxNum, width, height):
        self.maxEffectNum = maxNum 
        self.width = width
        self.height = height
        self.collection = list()
        for i in range(self.maxEffectNum):
            self.collection.append(SpecialEffect())

class SpecialEffect():
    def __init__(self, present = False, x = 0, y = 0, direction = (0,0), speed = 1, delay = 5):
        self.x = x
        self.y = y
        self.isPresent = present
        self.direction = direction
        self.speed = speed
        self.color = 'red'
        self.timelimit = 400
        self.time = 0
        self.delay = delay

    def run(self):
        if self.isPresent:
            self.x += self.direction[0]*self.speed
            self.y += self.direction[1]*self.speed

    def borderDetect(self, w, h):
        margin = 10
        if self.isPresent:
            if (self.x < -margin or self.x > w+margin or
                self.y < -margin or self.y > h+margin):
                self.isPresent = False
            self.time += self.delay
            if self.time >= self.timelimit:
                self.time = 0
                self.isPresent =  False
            